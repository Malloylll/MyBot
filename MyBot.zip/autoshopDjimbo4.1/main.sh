#!/bin/bash
cd autoshopDjimbo4.1&&python3.10 main.py